import {age} from './title';
age++;
export {
    age
};