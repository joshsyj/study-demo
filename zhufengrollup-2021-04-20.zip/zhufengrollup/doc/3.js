let b = 2;
function one(){
    var a = 1;
    console.log(b);
}
console.log(a);