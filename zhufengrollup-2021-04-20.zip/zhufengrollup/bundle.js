var age = 12;
function say(){
    console.log('hello',age);
}
say();